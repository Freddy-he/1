import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Compiler {

    /* ============================ 词法分析器 ============================ */

    static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
            "const", "int", "char", "void", "static",
            "if", "else", "while", "switch", "case", "default",
            "break", "continue", "return", "main", "printf"));

    static final String SINGLE_OPS = "+-*/%=<>!(){}[],;:";

    static boolean isDigit(char c) {
        return c >= '0' && c <= '9';
    }

    static boolean isAlpha(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
    }

    static final class Token {
        String type;
        String value;
        int line;
        int col;

        Token(String type, String value, int line, int col) {
            this.type = type;
            this.value = value;
            this.line = line;
            this.col = col;
        }
    }

    static final class Err {
        int line;
        int col;
        String code;
        String msg;

        Err(int line, int col, String code, String msg) {
            this.line = line;
            this.col = col;
            this.code = code;
            this.msg = msg;
        }
    }

    static final class LexOut {
        List<Token> tokens = new ArrayList<>();
        List<Err> errors = new ArrayList<>();
    }

    static void lexErr(LexOut out, int line, int col, String msg) {
        out.errors.add(new Err(line, col, "a", msg));
    }

    static LexOut lex(String src) {
        LexOut out = new LexOut();
        int n = src.length();
        int i = 0, line = 1, col = 1;

        while (i < n) {
            char c = src.charAt(i);
            if (c == '\n') { i++; line++; col = 1; continue; }
            if (c == ' ' || c == '\t' || c == '\r') { i++; col++; continue; }

            int sl = line, sc = col;

            if (c == '/' && i + 1 < n && src.charAt(i + 1) == '/') {
                while (i < n && src.charAt(i) != '\n') { i++; col++; }
                continue;
            }
            if (c == '/' && i + 1 < n && src.charAt(i + 1) == '*') {
                i += 2; col += 2;
                boolean closed = false;
                while (i < n) {
                    if (src.charAt(i) == '*' && i + 1 < n && src.charAt(i + 1) == '/') {
                        i += 2; col += 2; closed = true; break;
                    }
                    if (src.charAt(i) == '\n') { line++; col = 1; i++; } else { col++; i++; }
                }
                if (!closed) lexErr(out, sl, sc, "块注释未闭合，缺少 */");
                continue;
            }

            if (isAlpha(c)) {
                StringBuilder v = new StringBuilder();
                while (i < n && (isAlpha(src.charAt(i)) || isDigit(src.charAt(i)))) {
                    v.append(src.charAt(i)); i++; col++;
                }
                String val = v.toString();
                out.tokens.add(new Token(KEYWORDS.contains(val) ? "kw" : "ident", val, sl, sc));
                continue;
            }

            if (isDigit(c)) {
                StringBuilder v = new StringBuilder();
                while (i < n && isDigit(src.charAt(i))) { v.append(src.charAt(i)); i++; col++; }
                out.tokens.add(new Token("num", v.toString(), sl, sc));
                continue;
            }

            if (c == '\'') {
                int start = i;
                i++; col++;
                if (i < n && src.charAt(i) == '\\') {
                    i++; col++;
                    if (i < n) { i++; col++; }
                } else if (i < n && src.charAt(i) != '\n') {
                    i++; col++;
                }
                if (i < n && src.charAt(i) == '\'') {
                    i++; col++;
                    out.tokens.add(new Token("char", src.substring(start, i), sl, sc));
                } else {
                    lexErr(out, sl, sc, "字符常量未闭合，缺少 '''");
                    out.tokens.add(new Token("char", src.substring(start, i), sl, sc));
                }
                continue;
            }

            if (c == '"') {
                int start = i;
                i++; col++;
                boolean closed = false;
                while (i < n && src.charAt(i) != '\n') {
                    if (src.charAt(i) == '"') { i++; col++; closed = true; break; }
                    i++; col++;
                }
                if (!closed) lexErr(out, sl, sc, "字符串常量未闭合，缺少 \"");
                out.tokens.add(new Token("str", src.substring(start, i), sl, sc));
                continue;
            }

            String two = src.substring(i, Math.min(i + 2, n));
            if (two.equals("==") || two.equals("!=") || two.equals("<=")
                    || two.equals(">=") || two.equals("&&") || two.equals("||")) {
                out.tokens.add(new Token("op", two, sl, sc));
                i += 2; col += 2;
                continue;
            }

            if (SINGLE_OPS.indexOf(c) >= 0) {
                out.tokens.add(new Token("op", String.valueOf(c), sl, sc));
                i++; col++;
                continue;
            }

            if (c == '&' || c == '|') {
                lexErr(out, sl, sc, "非法符号 '" + c + "'，应写为 '" + c + "" + c + "'");
                out.tokens.add(new Token("op", "" + c + c, sl, sc));
                i++; col++;
                continue;
            }

            lexErr(out, sl, sc, "无法识别的字符 '" + c + "'");
            i++; col++;
        }

        out.tokens.add(new Token("eof", "文件结尾", line, col));
        return out;
    }

    /* ============================ 语法分析器（递归下降） ============================ */

    static final class Node {
        String type;
        int line = -1;
        int col = -1;
        int closeLine = -1;
        String name;
        String op;
        String val;
        String kind;
        String base;
        String ret;
        String to;
        String fmt;
        boolean isStatic;
        boolean isArray;
        Node index;
        Node init;
        Node size;
        Node num;
        Node expr;
        Node cond;
        Node thenStmt;
        Node alt;
        Node body;
        Node target;
        Node left;
        Node right;
        List<Node> items;
        List<Node> args;
        List<Node> defs;
        List<Node> params;
        List<Node> cases;
        List<Node> stmts;
        List<Node> decls;
        List<Node> funcs;
        Node main;

        static Node of(String type) {
            Node n = new Node();
            n.type = type;
            return n;
        }
    }

    interface Fn {
        Node get();
    }

    static final class Parser {
        final List<Token> tokens;
        int pos = 0;
        final List<Err> errors = new ArrayList<>();

        Parser(List<Token> tokens) {
            this.tokens = tokens;
        }

        Token peek(int k) {
            int idx = pos + k;
            return idx < tokens.size() ? tokens.get(idx) : null;
        }

        Token cur() {
            return tokens.get(pos);
        }

        boolean at(String v) {
            return cur().value.equals(v);
        }

        Token next() {
            return tokens.get(pos++);
        }

        boolean atEof() {
            return cur().type.equals("eof");
        }

        Token prevTok() {
            return pos > 0 ? tokens.get(pos - 1) : tokens.get(0);
        }

        void err(int line, int col, String code, String msg) {
            errors.add(new Err(line, col, code, msg));
        }

        // 错误 i / j / k：报告“前一个非终结符”所在行，不消费当前符号，按其已存在继续解析
        Token expect(String v, String code) {
            return expect(v, code, null);
        }

        Token expect(String v, String code, String customDesc) {
            if (at(v)) return next();
            Token t = prevTok();
            String desc = customDesc != null ? customDesc
                    : code.equals("i") ? "缺少分号 ';'"
                    : code.equals("j") ? "缺少右小括号 ')'"
                    : "缺少右中括号 ']'";
            err(t.line, t.col, code, desc + "（应位于 '" + cur().value + "' 之前）");
            return null;
        }

        Token identOrFail() {
            if (cur().type.equals("ident")) return next();
            err(cur().line, cur().col, "i", "期望标识符，但遇到 '" + cur().value + "'");
            return null;
        }

        Node numberNode(Token t) {
            Node n = Node.of("Number");
            n.kind = t.type.equals("num") ? "IntConst" : "CharConst";
            n.val = t.value;
            n.line = t.line;
            n.col = t.col;
            return n;
        }

        Node primary() {
            Token t = cur();
            if (t.type.equals("num") || t.type.equals("char")) {
                next();
                return numberNode(t);
            }
            if (t.type.equals("ident")) {
                next();
                if (at("(")) {
                    next();
                    List<Node> a = new ArrayList<>();
                    if (!at(")")) {
                        a.add(exp());
                        while (at(",")) { next(); a.add(exp()); }
                    }
                    expect(")", "j");
                    Node n = Node.of("Call");
                    n.name = t.value;
                    n.args = a;
                    n.line = t.line;
                    n.col = t.col;
                    return n;
                }
                Node n = Node.of("LVal");
                n.name = t.value;
                n.line = t.line;
                n.col = t.col;
                if (at("[")) {
                    next();
                    n.index = exp();
                    expect("]", "k");
                }
                return n;
            }
            if (t.value.equals("(")) {
                next();
                Node e = exp();
                expect(")", "j");
                Node n = Node.of("Group");
                n.expr = e;
                n.line = t.line;
                n.col = t.col;
                return n;
            }
            err(t.line, t.col, "i", "意外的符号 '" + t.value + "'，此处需要表达式");
            if (!t.type.equals("eof")) next();
            Node n = Node.of("Error");
            n.line = t.line;
            n.col = t.col;
            return n;
        }

        Node unary() {
            if (at("+") || at("-") || at("!")) {
                Token op = next();
                Node n = Node.of("Unary");
                n.op = op.value;
                n.expr = unary();
                n.line = op.line;
                n.col = op.col;
                return n;
            }
            Token p1 = peek(1);
            if (at("(") && p1 != null && p1.type.equals("kw")
                    && (p1.value.equals("int") || p1.value.equals("char"))) {
                Token lp = next();
                Token toT = next();
                expect(")", "j");
                Node n = Node.of("Cast");
                n.to = toT.value;
                n.expr = unary();
                n.line = lp.line;
                n.col = lp.col;
                return n;
            }
            return primary();
        }

        Node binLevel(Fn child, String... ops) {
            Node left = child.get();
            List<String> opList = Arrays.asList(ops);
            while (opList.contains(cur().value)
                    && (cur().type.equals("op") || cur().type.equals("kw"))) {
                Token op = next();
                Node n = Node.of("Binary");
                n.op = op.value;
                n.left = left;
                n.right = child.get();
                n.line = op.line;
                n.col = op.col;
                left = n;
            }
            return left;
        }

        Node mulExp() { return binLevel(this::unary, "*", "/", "%"); }
        Node addExp() { return binLevel(this::mulExp, "+", "-"); }
        Node relExp() { return binLevel(this::addExp, "<", ">", "<=", ">="); }
        Node eqExp() { return binLevel(this::relExp, "==", "!="); }
        Node andExp() { return binLevel(this::eqExp, "&&"); }
        Node orExp() { return binLevel(this::andExp, "||"); }
        Node exp() { return addExp(); }
        Node cond() { return orExp(); }
        Node constExp() { return addExp(); }

        Node number() {
            Token t = cur();
            if (t.type.equals("num") || t.type.equals("char")) {
                next();
                return numberNode(t);
            }
            err(t.line, t.col, "i", "期望 Number，但遇到 '" + t.value + "'");
            Node n = Node.of("Number");
            n.kind = "IntConst";
            n.val = "0";
            n.line = t.line;
            n.col = t.col;
            return n;
        }

        String bType() {
            if (at("int") || at("char")) return next().value;
            err(cur().line, cur().col, "i",
                    "期望基本类型 int / char，但遇到 '" + cur().value + "'");
            return "int";
        }

        Node constInitVal() {
            if (at("{")) {
                next();
                List<Node> items = new ArrayList<>();
                if (!at("}")) {
                    items.add(constExp());
                    while (at(",")) { next(); items.add(constExp()); }
                }
                expect("}", "i", "缺少右花括号 '}'");
                Node n = Node.of("InitList");
                n.items = items;
                return n;
            }
            if (cur().type.equals("str")) {
                Token t = next();
                Node n = Node.of("StringLit");
                n.val = t.value;
                n.line = t.line;
                n.col = t.col;
                return n;
            }
            Node n = Node.of("InitSingle");
            n.expr = constExp();
            return n;
        }

        Node initVal() {
            if (at("{")) {
                next();
                List<Node> items = new ArrayList<>();
                if (!at("}")) {
                    items.add(exp());
                    while (at(",")) { next(); items.add(exp()); }
                }
                expect("}", "i", "缺少右花括号 '}'");
                Node n = Node.of("InitList");
                n.items = items;
                return n;
            }
            if (cur().type.equals("str")) {
                Token t = next();
                Node n = Node.of("StringLit");
                n.val = t.value;
                n.line = t.line;
                n.col = t.col;
                return n;
            }
            Node n = Node.of("InitSingle");
            n.expr = exp();
            return n;
        }

        Node constDef() {
            Token name = identOrFail();
            int pl, pc;
            if (name != null) {
                pl = name.line; pc = name.col;
            } else {
                Token p = prevTok(); pl = p.line; pc = p.col;
            }
            Node def = Node.of("ConstDef");
            def.name = name != null ? name.value : "?err";
            def.line = pl;
            def.col = pc;
            if (at("[")) {
                next();
                def.size = constExp();
                expect("]", "k");
            }
            if (at("=")) {
                next();
            } else {
                Token p = prevTok();
                err(p.line, p.col, "i", "常量定义缺少 '=' 初始值");
            }
            def.init = constInitVal();
            return def;
        }

        Node varDef() {
            Token name = identOrFail();
            int pl, pc;
            if (name != null) {
                pl = name.line; pc = name.col;
            } else {
                Token p = prevTok(); pl = p.line; pc = p.col;
            }
            Node def = Node.of("VarDef");
            def.name = name != null ? name.value : "?err";
            def.line = pl;
            def.col = pc;
            if (at("[")) {
                next();
                def.size = constExp();
                expect("]", "k");
            }
            if (at("=")) {
                next();
                def.init = initVal();
            }
            return def;
        }

        Node constDecl() {
            Token kw = next();
            String base = bType();
            List<Node> defs = new ArrayList<>();
            defs.add(constDef());
            while (at(",")) { next(); defs.add(constDef()); }
            expect(";", "i");
            Node n = Node.of("ConstDecl");
            n.base = base;
            n.defs = defs;
            n.line = kw.line;
            n.col = kw.col;
            return n;
        }

        Node varDecl() {
            Token start = cur();
            boolean isStatic = at("static");
            if (isStatic) next();
            String base = bType();
            List<Node> defs = new ArrayList<>();
            defs.add(varDef());
            while (at(",")) { next(); defs.add(varDef()); }
            expect(";", "i");
            Node n = Node.of("VarDecl");
            n.isStatic = isStatic;
            n.base = base;
            n.defs = defs;
            n.line = start.line;
            n.col = start.col;
            return n;
        }

        Node decl() {
            return at("const") ? constDecl() : varDecl();
        }

        Node block() {
            Token open = cur();
            if (at("{")) next();
            else err(open.line, open.col, "j", "语句块缺少 '{'");
            List<Node> items = new ArrayList<>();
            while (!at("}") && !atEof()) {
                items.add(blockItem());
            }
            int closeLine = open.line;
            if (atEof()) {
                err(open.line, open.col, "j", "第 " + open.line + " 行的 '{' 未闭合");
            } else {
                closeLine = cur().line;
                next();
            }
            Node n = Node.of("Block");
            n.items = items;
            n.line = open.line;
            n.col = open.col;
            n.closeLine = closeLine;
            return n;
        }

        Node blockItem() {
            if (at("const") || at("static") || at("int") || at("char")) return decl();
            return stmt();
        }

        Node caseStmt() {
            Token kw = cur();
            boolean isCase = at("case");
            next();
            Node num = null;
            if (isCase) num = number();
            expect(":", "j", "缺少 ':'");
            List<Node> body = new ArrayList<>();
            while (!at("case") && !at("default") && !at("}") && !atEof()) {
                body.add(stmt());
            }
            Node n = Node.of(isCase ? "Case" : "Default");
            n.num = num;
            n.stmts = body;
            n.line = kw.line;
            n.col = kw.col;
            return n;
        }

        Node stmt() {
            Token t = cur();

            if (t.value.equals("{")) return block();

            if (t.value.equals(";")) {
                next();
                Node n = Node.of("ExprStmt");
                n.expr = null;
                n.line = t.line;
                n.col = t.col;
                return n;
            }

            if (t.value.equals("if")) {
                next();
                expect("(", "j", "缺少左小括号 '('");
                Node c = cond();
                expect(")", "j");
                Node then = stmt();
                Node alt = null;
                if (at("else")) { next(); alt = stmt(); }
                Node n = Node.of("If");
                n.cond = c;
                n.thenStmt = then;
                n.alt = alt;
                n.line = t.line;
                n.col = t.col;
                return n;
            }

            if (t.value.equals("while")) {
                next();
                expect("(", "j", "缺少左小括号 '('");
                Node c = cond();
                expect(")", "j");
                Node body = stmt();
                Node n = Node.of("While");
                n.cond = c;
                n.body = body;
                n.line = t.line;
                n.col = t.col;
                return n;
            }

            if (t.value.equals("switch")) {
                next();
                expect("(", "j", "缺少左小括号 '('");
                Node e = exp();
                expect(")", "j");
                expect("{", "j", "缺少左花括号 '{'");
                List<Node> cases = new ArrayList<>();
                while (at("case") || at("default")) cases.add(caseStmt());
                expect("}", "j", "缺少右花括号 '}'");
                Node n = Node.of("Switch");
                n.expr = e;
                n.cases = cases;
                n.line = t.line;
                n.col = t.col;
                return n;
            }

            if (t.value.equals("break") || t.value.equals("continue")) {
                next();
                expect(";", "i");
                Node n = Node.of(t.value.equals("break") ? "Break" : "Continue");
                n.line = t.line;
                n.col = t.col;
                return n;
            }

            if (t.value.equals("return")) {
                next();
                Node v = null;
                if (!at(";")) v = exp();
                expect(";", "i");
                Node n = Node.of("Return");
                n.expr = v;
                n.line = t.line;
                n.col = t.col;
                return n;
            }

            if (t.value.equals("printf")) {
                next();
                expect("(", "j", "缺少左小括号 '('");
                String fmt = null;
                if (cur().type.equals("str")) fmt = next().value;
                else err(cur().line, cur().col, "i", "printf 需要字符串格式参数");
                List<Node> args = new ArrayList<>();
                while (at(",")) { next(); args.add(exp()); }
                expect(")", "j");
                expect(";", "i");
                Node n = Node.of("Printf");
                n.fmt = fmt;
                n.args = args;
                n.line = t.line;
                n.col = t.col;
                return n;
            }

            Node e = exp();
            if (at("=")) {
                next();
                Node value = exp();
                expect(";", "i");
                Node n = Node.of("Assign");
                n.target = e;
                n.expr = value;
                n.line = e.line;
                n.col = e.col;
                return n;
            }
            expect(";", "i");
            Node n = Node.of("ExprStmt");
            n.expr = e;
            n.line = e.line;
            n.col = e.col;
            return n;
        }

        boolean looksLikeFunc() {
            Token t1 = peek(1);
            Token t2 = peek(2);
            if (t1 == null) return false;
            if (t1.type.equals("kw") && t1.value.equals("main")) return true;
            if (t1.type.equals("ident") && t2 != null && t2.value.equals("(")) return true;
            return false;
        }

        Node compUnit() {
            List<Node> decls = new ArrayList<>();
            List<Node> funcs = new ArrayList<>();
            Node main = null;
            while (!atEof()) {
                if (at("const")) {
                    decls.add(constDecl());
                } else if (at("static")) {
                    decls.add(varDecl());
                } else if (at("void") || ((at("int") || at("char")) && looksLikeFunc())) {
                    Token p1 = peek(1);
                    if (p1 != null && p1.value.equals("main")) main = mainFuncDef();
                    else funcs.add(funcDef());
                } else if (at("int") || at("char")) {
                    decls.add(varDecl());
                } else {
                    err(cur().line, cur().col, "i",
                            "意外的符号 '" + cur().value + "'，此处需要声明或函数定义");
                    next();
                }
            }
            Node n = Node.of("Program");
            n.decls = decls;
            n.funcs = funcs;
            n.main = main;
            return n;
        }

        Node funcFParam() {
            String base = bType();
            Token name = identOrFail();
            int pl, pc;
            if (name != null) { pl = name.line; pc = name.col; }
            else { Token p = prevTok(); pl = p.line; pc = p.col; }
            Node param = Node.of("FuncFParam");
            param.base = base;
            param.name = name != null ? name.value : "?err";
            param.line = pl;
            param.col = pc;
            if (at("[")) {
                next();
                param.isArray = true;
                expect("]", "k");
            }
            return param;
        }

        Node funcDef() {
            Token rt = next();
            Token nameT = identOrFail();
            int pl, pc;
            if (nameT != null) { pl = nameT.line; pc = nameT.col; }
            else { Token p = prevTok(); pl = p.line; pc = p.col; }
            expect("(", "j", "缺少左小括号 '('");
            List<Node> params = new ArrayList<>();
            while (at("int") || at("char")) {
                params.add(funcFParam());
                if (at(",")) next();
                else break;
            }
            expect(")", "j");
            Node body = block();
            Node n = Node.of("FuncDef");
            n.ret = rt.value;
            n.name = nameT != null ? nameT.value : "?err";
            n.params = params;
            n.body = body;
            n.line = pl;
            n.col = pc;
            return n;
        }

        Node mainFuncDef() {
            Token kw = next();
            next();
            expect("(", "j", "缺少左小括号 '('");
            expect(")", "j");
            Node body = block();
            Node n = Node.of("MainFuncDef");
            n.body = body;
            n.line = kw.line;
            n.col = kw.col;
            return n;
        }
    }

    /* ============================ 语义分析器 ============================ */

    static final Map<String, String[]> RUNTIME_FUNCS = new HashMap<>();

    static {
        RUNTIME_FUNCS.put("get_int", new String[]{"int"});
        RUNTIME_FUNCS.put("get_char", new String[]{"char"});
        RUNTIME_FUNCS.put("get_string", new String[]{"void", "char[]", "int"});
        RUNTIME_FUNCS.put("put_int", new String[]{"void", "int"});
        RUNTIME_FUNCS.put("put_char", new String[]{"void", "char"});
        RUNTIME_FUNCS.put("put_str", new String[]{"void", "char[]"});
    }

    static final class Sym {
        String kind;
        String base;
        String ret;
        boolean isArray;
        boolean isStatic;
        List<String> params;
    }

    static final class Scope {
        final int id;
        final Map<String, Sym> map = new LinkedHashMap<>();

        Scope(int id) {
            this.id = id;
        }
    }

    static final class SymEntry {
        int scopeId;
        int seq;
        String word;
        String typeName;
    }

    static final class SemOut {
        final List<Err> errors = new ArrayList<>();
        final List<SymEntry> symbols = new ArrayList<>();
    }

    static final class Semantic {
        final SemOut out = new SemOut();
        final List<Scope> scopes = new ArrayList<>();
        int scopeCounter = 0;
        int seq = 0;
        String currentRet = "void";
        int loopDepth = 0;
        int switchDepth = 0;

        void err(int line, int col, String code, String msg) {
            out.errors.add(new Err(line, col > 0 ? col : 1, code, msg));
        }

        boolean isBase(String t) {
            return t.equals("int") || t.equals("char");
        }

        void pushScope() {
            scopes.add(new Scope(++scopeCounter));
        }

        void popScope() {
            scopes.remove(scopes.size() - 1);
        }

        String typeNameOf(Sym s) {
            if (s.kind.equals("func")) {
                return s.ret.equals("void") ? "VoidFunc" : s.ret.equals("int") ? "IntFunc" : "CharFunc";
            }
            String b = s.base;
            if (s.kind.equals("const")) {
                return s.isArray ? (b.equals("int") ? "ConstIntArray" : "ConstCharArray")
                        : (b.equals("int") ? "ConstInt" : "ConstChar");
            }
            if (s.isStatic) {
                return s.isArray ? (b.equals("int") ? "StaticIntArray" : "StaticCharArray")
                        : (b.equals("int") ? "StaticInt" : "StaticChar");
            }
            return s.isArray ? (b.equals("int") ? "IntArray" : "CharArray")
                    : (b.equals("int") ? "Int" : "Char");
        }

        void declare(String word, Sym sym, int line, int col) {
            if (word.startsWith("?err")) return;
            Scope sc = scopes.get(scopes.size() - 1);
            if (sc.map.containsKey(word)) {
                err(line, col, "b", "名字重定义：" + word + " 在作用域 " + sc.id + " 中已定义");
            }
            sc.map.put(word, sym);
            SymEntry e = new SymEntry();
            e.scopeId = sc.id;
            e.seq = ++seq;
            e.word = word;
            e.typeName = typeNameOf(sym);
            out.symbols.add(e);
        }

        Sym lookup(String word) {
            for (int i = scopes.size() - 1; i >= 0; i--) {
                Sym s = scopes.get(i).map.get(word);
                if (s != null) return s;
            }
            return null;
        }

        String typeOf(Node e) {
            if (e == null) return "int";
            switch (e.type) {
                case "Number":
                    return e.kind.equals("IntConst") ? "int" : "char";
                case "Error":
                    return "int";
                case "Group":
                    return typeOf(e.expr);
                case "LVal": {
                    Sym sym = lookup(e.name);
                    if (sym == null) {
                        err(e.line, e.col, "c", "未定义的名字：" + e.name);
                        return "int";
                    }
                    if (sym.kind.equals("func")) {
                        err(e.line, e.col, "e", "类型不匹配：函数 " + e.name + " 被当作变量使用");
                        return "int";
                    }
                    if (e.index == null) {
                        return sym.isArray ? sym.base + "[]" : sym.base;
                    }
                    if (!sym.isArray) {
                        err(e.line, e.col, "e", "类型不匹配：非数组变量 " + e.name + " 进行了数组访问");
                        typeOf(e.index);
                        return sym.base;
                    }
                    String it = typeOf(e.index);
                    if (!it.equals("int")) {
                        err(e.index.line, e.index.col, "e", "类型不匹配：数组下标必须是 int 类型");
                    }
                    return sym.base;
                }
                case "Unary": {
                    String t = typeOf(e.expr);
                    if (e.op.equals("!")) return "int";
                    if (!isBase(t)) {
                        err(e.line, e.col, "e", "类型不匹配：一元运算符操作数不是基本类型");
                        return "int";
                    }
                    return t;
                }
                case "Cast": {
                    String t = typeOf(e.expr);
                    if (!isBase(t)) {
                        err(e.line, e.col, "e", "类型不匹配：显式类型转换的操作数必须是 int 或 char");
                    }
                    return e.to;
                }
                case "Binary": {
                    String l = typeOf(e.left);
                    String r = typeOf(e.right);
                    boolean rel = e.op.equals("<") || e.op.equals("<=") || e.op.equals(">")
                            || e.op.equals(">=") || e.op.equals("==") || e.op.equals("!=");
                    boolean logic = e.op.equals("&&") || e.op.equals("||");
                    if (logic) {
                        if (!isBase(l) || !isBase(r)) {
                            err(e.line, e.col, "e", "类型不匹配：逻辑运算操作数必须是基本类型");
                        }
                        return "int";
                    }
                    if (!isBase(l) || !isBase(r)) {
                        err(e.line, e.col, "e", "类型不匹配：" + e.op + " 的操作数不是基本类型");
                        return "int";
                    }
                    if (!l.equals(r)) {
                        err(e.line, e.col, "e",
                                "类型不匹配：" + l + " 与 " + r + " 不能进行 " + e.op + " 混合运算");
                        return rel ? "int" : (l.equals("char") ? "char" : "int");
                    }
                    if (rel) return "int";
                    return l;
                }
                case "Call": {
                    Sym sym = lookup(e.name);
                    List<String> argTypes = new ArrayList<>();
                    for (Node a : e.args) argTypes.add(typeOf(a));
                    if (sym == null) {
                        String[] rf = RUNTIME_FUNCS.get(e.name);
                        if (rf == null) {
                            err(e.line, e.col, "c", "未定义的函数：" + e.name);
                        } else {
                            checkArgs(e, argTypes, Arrays.asList(rf).subList(1, rf.length));
                        }
                        return "int";
                    }
                    if (!sym.kind.equals("func")) {
                        err(e.line, e.col, "e", "类型不匹配：变量 " + e.name + " 被当作函数调用");
                        return "int";
                    }
                    if (e.args.size() != sym.params.size()) {
                        err(e.line, e.col, "d",
                                "函数参数个数不匹配：" + e.name + " 需要 " + sym.params.size()
                                        + " 个参数，实参 " + e.args.size() + " 个");
                        return sym.ret;
                    }
                    checkArgs(e, argTypes, sym.params);
                    return sym.ret;
                }
                default:
                    return "int";
            }
        }

        void checkArgs(Node call, List<String> argTypes, List<String> paramTypes) {
            for (int i = 0; i < argTypes.size() && i < paramTypes.size(); i++) {
                if (!argTypes.get(i).equals(paramTypes.get(i))) {
                    err(call.line, call.col, "e",
                            "类型不匹配：第 " + (i + 1) + " 个实参为 " + argTypes.get(i)
                                    + "，形参为 " + paramTypes.get(i));
                    return;
                }
            }
        }

        void checkInit(Node def, String base, boolean isArray, Node init) {
            if (init == null) return;
            if (init.type.equals("StringLit")) {
                if (!isArray || !base.equals("char")) {
                    err(def.line, def.col, "e", "类型不匹配：字符串只能初始化 char 数组");
                }
                return;
            }
            if (init.type.equals("InitSingle")) {
                String t = typeOf(init.expr);
                if (!t.equals(base)) {
                    err(def.line, def.col, "e",
                            "类型不匹配：初值为 " + t + "，声明类型为 " + base);
                }
                return;
            }
            for (Node item : init.items) {
                String t = typeOf(item);
                if (!t.equals(base)) {
                    err(def.line, def.col, "e",
                            "类型不匹配：数组初值含 " + t + "，声明类型为 " + base);
                    return;
                }
            }
        }

        void doDecl(Node node) {
            if (node.type.equals("ConstDecl")) {
                for (Node d : node.defs) {
                    checkInit(d, node.base, d.size != null, d.init);
                    Sym s = new Sym();
                    s.kind = "const";
                    s.base = node.base;
                    s.isArray = d.size != null;
                    declare(d.name, s, d.line, d.col);
                }
            } else {
                for (Node d : node.defs) {
                    checkInit(d, node.base, d.size != null, d.init);
                    Sym s = new Sym();
                    s.kind = "var";
                    s.base = node.base;
                    s.isArray = d.size != null;
                    s.isStatic = node.isStatic;
                    declare(d.name, s, d.line, d.col);
                }
            }
        }

        void walkStmt(Node s) {
            if (s == null) return;
            switch (s.type) {
                case "Block":
                    pushScope();
                    for (Node it : s.items) {
                        if (it.type.equals("ConstDecl") || it.type.equals("VarDecl")) doDecl(it);
                        else walkStmt(it);
                    }
                    popScope();
                    break;

                case "ExprStmt":
                    if (s.expr != null) typeOf(s.expr);
                    break;

                case "Assign": {
                    Node target = s.target;
                    if (target != null && target.type.equals("LVal")) {
                        Sym sym = lookup(target.name);
                        if (sym == null) {
                            err(target.line, target.col, "c", "未定义的名字：" + target.name);
                            typeOf(s.expr);
                            break;
                        }
                        if (sym.kind.equals("const")) {
                            err(target.line, target.col, "h",
                                    "不能改变常量的值：" + target.name + " 是常量");
                            typeOf(s.expr);
                            break;
                        }
                        if (sym.kind.equals("func")) {
                            err(target.line, target.col, "e",
                                    "类型不匹配：不能给函数 " + target.name + " 赋值");
                            typeOf(s.expr);
                            break;
                        }
                        String tt = typeOf(target);
                        String vt = typeOf(s.expr);
                        if (!tt.equals(vt)) {
                            err(target.line, target.col, "e",
                                    "类型不匹配：左值为 " + tt + "，右值为 " + vt);
                        }
                    } else {
                        typeOf(s.expr);
                    }
                    break;
                }

                case "If":
                    typeOf(s.cond);
                    walkStmt(s.thenStmt);
                    if (s.alt != null) walkStmt(s.alt);
                    break;

                case "While":
                    typeOf(s.cond);
                    loopDepth++;
                    walkStmt(s.body);
                    loopDepth--;
                    break;

                case "Switch": {
                    String et = typeOf(s.expr);
                    boolean typeOk = isBase(et);
                    if (!typeOk) {
                        err(s.line, s.col, "e", "类型不匹配：switch 表达式必须是 int 或 char");
                    }
                    Set<String> seen = new HashSet<>();
                    boolean hasDefault = false;
                    switchDepth++;
                    for (Node c : s.cases) {
                        if (c.type.equals("Case")) {
                            String nt = c.num.kind.equals("IntConst") ? "int" : "char";
                            String key = c.num.kind + ":" + c.num.val;
                            if (!seen.add(key)) {
                                err(c.line, c.col, "n",
                                        "switch 语句中 case 值重复：" + c.num.val);
                            }
                            if (typeOk && !nt.equals(et)) {
                                err(c.line, c.col, "e",
                                        "类型不匹配：case 常量为 " + nt + "，switch 表达式为 " + et);
                            }
                        } else {
                            if (hasDefault) {
                                err(c.line, c.col, "n", "switch 语句中出现多个 default 分支");
                            }
                            hasDefault = true;
                        }
                        for (Node st : c.stmts) walkStmt(st);
                    }
                    switchDepth--;
                    break;
                }

                case "Break":
                    if (loopDepth == 0 && switchDepth == 0) {
                        err(s.line, s.col, "m", "break 语句不能出现在非循环/switch 块中");
                    }
                    break;

                case "Continue":
                    if (loopDepth == 0) {
                        err(s.line, s.col, "m", "continue 语句只能出现在 while 循环中");
                    }
                    break;

                case "Return": {
                    if (s.expr != null) {
                        String t = typeOf(s.expr);
                        if (currentRet.equals("void")) {
                            err(s.line, s.col, "f", "无返回值的函数存在不匹配的 return 语句");
                        } else if (!t.equals(currentRet)) {
                            err(s.line, s.col, "e",
                                    "类型不匹配：return 值为 " + t + "，函数声明返回 " + currentRet);
                        }
                    }
                    break;
                }

                case "Printf": {
                    List<String> slots = fmtSlots(s.fmt);
                    List<String> argTypes = new ArrayList<>();
                    for (Node a : s.args) argTypes.add(typeOf(a));
                    if (slots.size() != s.args.size()) {
                        err(s.line, s.col, "l",
                                "printf 格式字符个数（" + slots.size() + "）与表达式个数（"
                                        + s.args.size() + "）不匹配");
                    } else {
                        for (int i = 0; i < slots.size(); i++) {
                            if (!argTypes.get(i).equals(slots.get(i))) {
                                Node a = s.args.get(i);
                                int al = a.line >= 0 ? a.line : s.line;
                                int ac = a.col >= 0 ? a.col : s.col;
                                err(al, ac, "e",
                                        "类型不匹配：格式符为 " + slots.get(i)
                                                + "，表达式为 " + argTypes.get(i));
                                break;
                            }
                        }
                    }
                    break;
                }

                default:
                    break;
            }
        }

        List<String> fmtSlots(String fmt) {
            List<String> slots = new ArrayList<>();
            if (fmt == null || fmt.length() <= 1) return slots;
            String body = fmt.substring(1, fmt.length() - 1);
            for (int i = 0; i < body.length(); i++) {
                if (body.charAt(i) == '%' && i + 1 < body.length()) {
                    char c = body.charAt(i + 1);
                    if (c == 'd') slots.add("int");
                    else if (c == 'c') slots.add("char");
                    else if (c == 's') slots.add("char[]");
                    else { i++; continue; }
                    i++;
                }
            }
            return slots;
        }

        Node lastStmt(Node block) {
            if (block == null || block.items == null || block.items.isEmpty()) return null;
            Node s = block.items.get(block.items.size() - 1);
            while (s != null && s.type.equals("Block")) s = lastStmt(s);
            return s;
        }

        void walkFunc(Node f) {
            Sym fs = new Sym();
            fs.kind = "func";
            fs.ret = f.ret;
            fs.params = new ArrayList<>();
            for (Node p : f.params) fs.params.add(p.base + (p.isArray ? "[]" : ""));
            declare(f.name, fs, f.line, f.col);
            pushScope();
            String savedRet = currentRet;
            currentRet = f.ret;
            for (Node p : f.params) {
                Sym ps = new Sym();
                ps.kind = "param";
                ps.base = p.base;
                ps.isArray = p.isArray;
                declare(p.name, ps, p.line, p.col);
            }
            for (Node it : f.body.items) {
                if (it.type.equals("ConstDecl") || it.type.equals("VarDecl")) doDecl(it);
                else walkStmt(it);
            }
            if (!f.ret.equals("void")) {
                Node last = lastStmt(f.body);
                if (last == null || !last.type.equals("Return") || last.expr == null) {
                    err(f.body.closeLine, 1, "g",
                            "有返回值的函数 " + f.name + " 缺少 return 语句");
                }
            }
            currentRet = savedRet;
            popScope();
        }

        void walkMain(Node m) {
            pushScope();
            String savedRet = currentRet;
            currentRet = "int";
            for (Node it : m.body.items) {
                if (it.type.equals("ConstDecl") || it.type.equals("VarDecl")) doDecl(it);
                else walkStmt(it);
            }
            Node last = lastStmt(m.body);
            if (last == null || !last.type.equals("Return") || last.expr == null) {
                err(m.body.closeLine, 1, "g", "有返回值的函数 main 缺少 return 语句");
            }
            currentRet = savedRet;
            popScope();
        }
    }

    static SemOut analyze(Node ast) {
        Semantic s = new Semantic();
        s.pushScope();
        for (Node d : ast.decls) s.doDecl(d);
        for (Node f : ast.funcs) s.walkFunc(f);
        if (ast.main != null) s.walkMain(ast.main);
        return s.out;
    }

    /* ============================ 编译前端入口 ============================ */

    static final class Result {
        List<Err> errors;
        List<SymEntry> symbols;
    }

    static Result compile(String src) {
        LexOut lexed = lex(src);
        Parser parser = new Parser(lexed.tokens);
        Node ast = parser.compUnit();
        SemOut sem = analyze(ast);
        List<Err> errors = new ArrayList<>(lexed.errors);
        errors.addAll(parser.errors);
        errors.addAll(sem.errors);
        errors.sort(Comparator.comparingInt((Err e) -> e.line).thenComparingInt(e -> e.col));
        Result r = new Result();
        r.errors = errors;
        r.symbols = sem.symbols;
        return r;
    }

    static String errorOutput(List<Err> errors) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < errors.size(); i++) {
            if (i > 0) sb.append('\n');
            Err e = errors.get(i);
            sb.append(e.line).append(' ').append(e.code);
        }
        return sb.toString();
    }

    static String symbolOutput(List<SymEntry> symbols) {
        List<SymEntry> sorted = new ArrayList<>(symbols);
        sorted.sort(Comparator.comparingInt((SymEntry s) -> s.scopeId)
                .thenComparingInt(s -> s.seq));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sorted.size(); i++) {
            if (i > 0) sb.append('\n');
            SymEntry s = sorted.get(i);
            sb.append(s.scopeId).append(' ').append(s.word).append(' ').append(s.typeName);
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        // 忽略命令行参数（--compile / --interp），输入输出固定为当前目录下的约定文件
        String src = "";
        try {
            Path in = Paths.get("testfile.txt");
            if (Files.exists(in)) {
                src = new String(Files.readAllBytes(in), StandardCharsets.UTF_8);
                if (!src.isEmpty() && src.charAt(0) == '﻿') src = src.substring(1);
            }
        } catch (IOException ignored) {
        }

        Result res = compile(src);

        try {
            if (!res.errors.isEmpty()) {
                Files.write(Paths.get("error.txt"),
                        errorOutput(res.errors).getBytes(StandardCharsets.UTF_8));
                Files.deleteIfExists(Paths.get("symbol.txt"));
            } else {
                Files.write(Paths.get("symbol.txt"),
                        symbolOutput(res.symbols).getBytes(StandardCharsets.UTF_8));
                Files.deleteIfExists(Paths.get("error.txt"));
            }
        } catch (IOException ignored) {
        }
    }
}
